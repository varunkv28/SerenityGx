import { useState } from "react";
import { DesignTokens } from "../constants/designTokens";
import TopNav from "./TopNav";

const T = DesignTokens;

const MONTHLY = [
  { month: "Aug", pending: 4, overdue: 1, resolved: 9 },
  { month: "Sep", pending: 6, overdue: 2, resolved: 11 },
  { month: "Oct", pending: 3, overdue: 1, resolved: 8 },
  { month: "Nov", pending: 8, overdue: 3, resolved: 14 },
  { month: "Dec", pending: 5, overdue: 2, resolved: 10 },
  { month: "Jan", pending: 7, overdue: 2, resolved: 12 },
];

const CLASSIFICATION_DIST = [
  { label: "Pathogenic", key: "P", count: 186, pct: 22, color: T.red },
  { label: "Likely Pathogenic", key: "LP", count: 142, pct: 17, color: "#E07B39" },
  { label: "VUS", key: "VUS", count: 312, pct: 37, color: T.primary },
  { label: "Likely Benign", key: "LB", count: 124, pct: 15, color: T.navy },
  { label: "Benign", key: "B", count: 83, pct: 9, color: T.green },
];

const REVIEWER_ACTIVITY = [
  { name: "Dr. S. Chen", role: "Laboratory Director", reviewed: 34, pending: 2, avgDays: 1.2, lastActive: "2 hours ago" },
  { name: "Dr. J. Park", role: "Genetic Counselor", reviewed: 28, pending: 5, avgDays: 2.8, lastActive: "Yesterday" },
  { name: "Dr. M. Torres", role: "Genetic Counselor", reviewed: 19, pending: 3, avgDays: 3.4, lastActive: "Jan 26" },
  { name: "Dr. R. Davis", role: "Lab Technician", reviewed: 8, pending: 1, avgDays: 4.1, lastActive: "Jan 24" },
];

const OVERDUE_ITEMS = [
  { id: "VAR-0115", gene: "PTEN", hgvs: "c.388C>T", daysOverdue: 127, classification: "VUS", assignedTo: "Unassigned" },
  { id: "VAR-0133", gene: "PALB2", hgvs: "c.2167_2168del", daysOverdue: 98, classification: "VUS", assignedTo: "Dr. J. Park" },
];

function HBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div style={{ flex: 1, height: 7, background: T.borderLight, borderRadius: 4, overflow: "hidden" }}>
      <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 4, transition: "width 0.6s ease" }} />
    </div>
  );
}

function DonutRing({ segments, size = 120 }: { segments: { label: string; count: number; color: string }[]; size?: number }) {
  const total = segments.reduce((a, s) => a + s.count, 0);
  let cumPct = 0;
  const gradientParts = segments.map(s => {
    const start = cumPct;
    const pct = (s.count / total) * 100;
    cumPct += pct;
    return `${s.color} ${start}% ${cumPct}%`;
  });
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: `conic-gradient(${gradientParts.join(", ")})`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <div style={{ width: size - 28, height: size - 28, borderRadius: "50%", background: T.white, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
        <div style={{ fontSize: 20, fontWeight: 700, color: T.navyDeep, lineHeight: 1, fontFamily: T.fontSerif }}>{total}</div>
        <div style={{ fontSize: 9, color: T.text3, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.4 }}>Total</div>
      </div>
    </div>
  );
}

export default function LeadershipDashboard({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const [timeRange, setTimeRange] = useState("6mo");

  const maxVol = Math.max(...MONTHLY.map(m => m.pending + m.overdue + m.resolved));

  return (
    <div style={{ fontFamily: T.font, background: T.surface, minHeight: "100vh", color: T.text1 }}>
      <TopNav activePage="Leadership Dashboard" onNavigate={onNavigate} />

      <main style={{ maxWidth: 1300, margin: "0 auto", padding: "28px 32px 48px" }}>
        {/* Breadcrumb */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: T.text3, marginBottom: 16 }}>
          <span onClick={() => onNavigate && onNavigate("Dashboard")} style={{ color: T.primary, cursor: "pointer", fontWeight: 500 }}>Dashboard</span>
          <span>›</span><span>Leadership Dashboard</span>
        </div>

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
          <div>
            <div style={{ fontFamily: T.fontSerif, fontSize: 26, fontWeight: 700, color: T.navyDeep, letterSpacing: -0.3 }}>Leadership Dashboard</div>
            <div style={{ color: T.text3, fontSize: 13.5, marginTop: 4 }}>Volume metrics, ageing analysis, and operational oversight</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ fontSize: 12, color: T.text3, fontWeight: 500 }}>Period:</span>
            {["3mo", "6mo", "1yr", "All"].map(r => (
              <button key={r} onClick={() => setTimeRange(r)} style={{ fontSize: 12, padding: "5px 12px", borderRadius: 20, border: `1px solid ${timeRange === r ? T.primary : T.border}`, background: timeRange === r ? T.primaryMuted : T.white, color: timeRange === r ? T.primary : T.text2, cursor: "pointer", fontFamily: T.font, fontWeight: 500 }}>{r}</button>
            ))}
            <button style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "8px 16px", borderRadius: T.radiusSm, fontSize: 12.5, fontWeight: 500, cursor: "pointer", background: T.white, color: T.text2, border: `1px solid ${T.border}`, fontFamily: T.font, marginLeft: 8 }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Export CSV
            </button>
            <button style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "8px 16px", borderRadius: T.radiusSm, fontSize: 12.5, fontWeight: 500, cursor: "pointer", background: `linear-gradient(135deg, ${T.navy}, ${T.primary})`, color: "white", border: "none", fontFamily: T.font }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Export PDF
            </button>
          </div>
        </div>

        {/* KPI Cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 14, marginBottom: 28 }}>
          {[
            { label: "Pending Reviews", value: "7", sub: "Require attention", color: T.amber, detail: "2 assigned · 5 unassigned" },
            { label: "Overdue (>90 days)", value: "2", sub: "Immediate action needed", color: T.red, detail: "Avg 112 days overdue" },
            { label: "Avg Review Time", value: "4.2d", sub: "This period", color: T.primary, detail: "↓ 0.8d vs prior period" },
            { label: "Classifications Changed", value: "5", sub: "Last 6 months", color: T.navy, detail: "3 upgrades · 2 downgrades" },
            { label: "Cases Resolved", value: "38", sub: "Last 6 months", color: T.green, detail: "100% resolution rate" },
          ].map((s, i) => (
            <div key={i} style={{ background: T.white, border: `1px solid ${T.borderLight}`, borderRadius: T.radius, padding: "18px 20px", position: "relative", overflow: "hidden", animation: `fadeInUp 0.4s ease ${i * 0.05}s both`, boxShadow: "0 1px 4px rgba(13,31,76,0.05)" }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: s.color }} />
              <div style={{ fontSize: 28, fontWeight: 700, color: T.navyDeep, fontFamily: T.fontSerif, letterSpacing: -0.5 }}>{s.value}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: T.text3, textTransform: "uppercase", letterSpacing: 0.5, marginTop: 4 }}>{s.label}</div>
              <div style={{ fontSize: 11, color: T.text3, marginTop: 2 }}>{s.detail}</div>
            </div>
          ))}
        </div>

        {/* Charts Row */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
          {/* Review Volume Chart */}
          <div style={{ background: T.white, border: `1px solid ${T.borderLight}`, borderRadius: T.radiusLg, padding: "20px 24px", boxShadow: "0 1px 4px rgba(13,31,76,0.05)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: T.navyDeep, fontFamily: T.fontSerif }}>Review Volume & Ageing</div>
              <div style={{ display: "flex", gap: 12, fontSize: 10.5, color: T.text3 }}>
                <span style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: T.primary }} /> Resolved</span>
                <span style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: T.amber }} /> Pending</span>
                <span style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 8, height: 8, borderRadius: 2, background: T.red }} /> Overdue</span>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 130, padding: "0 4px" }}>
              {MONTHLY.map((d, i) => {
                const resH = (d.resolved / maxVol) * 110;
                const penH = (d.pending / maxVol) * 110;
                const ovH = (d.overdue / maxVol) * 110;
                return (
                  <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                    <div style={{ width: "100%", maxWidth: 40, display: "flex", flexDirection: "column-reverse", borderRadius: "4px 4px 0 0", overflow: "hidden" }}>
                      <div style={{ height: resH, background: T.primary, transition: "height 0.5s ease" }} />
                      <div style={{ height: penH, background: T.amber, transition: "height 0.5s ease" }} />
                      <div style={{ height: ovH, background: T.red, transition: "height 0.5s ease" }} />
                    </div>
                    <span style={{ fontSize: 10, color: T.text3, fontWeight: 500 }}>{d.month}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Classification Distribution */}
          <div style={{ background: T.white, border: `1px solid ${T.borderLight}`, borderRadius: T.radiusLg, padding: "20px 24px", boxShadow: "0 1px 4px rgba(13,31,76,0.05)" }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: T.navyDeep, marginBottom: 16, fontFamily: T.fontSerif }}>Classification Distribution</div>
            <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
              <DonutRing segments={CLASSIFICATION_DIST} size={120} />
              <div style={{ display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
                {CLASSIFICATION_DIST.map((c, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ width: 10, height: 10, borderRadius: "50%", background: c.color, flexShrink: 0 }} />
                    <span style={{ fontSize: 12, color: T.text2, flex: 1 }}>{c.label}</span>
                    <HBar value={c.count} max={400} color={c.color} />
                    <span style={{ fontSize: 12, fontWeight: 700, color: T.navyDeep, width: 36, textAlign: "right" }}>{c.count}</span>
                    <span style={{ fontSize: 10.5, color: T.text3, width: 28 }}>{c.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Row: Overdue + Reviewer Activity */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          {/* Overdue Items */}
          <div style={{ background: T.white, border: `1px solid ${T.borderLight}`, borderRadius: T.radiusLg, overflow: "hidden", boxShadow: "0 1px 4px rgba(13,31,76,0.05)" }}>
            <div style={{ padding: "16px 22px", borderBottom: `1px solid ${T.borderLight}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: T.navyDeep, fontFamily: T.fontSerif, display: "flex", alignItems: "center", gap: 8 }}>
                ⏰ Overdue Reviews
                <span style={{ background: T.redLight, color: T.red, fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 10 }}>{OVERDUE_ITEMS.length}</span>
              </div>
            </div>
            <div style={{ padding: "4px 0" }}>
              {OVERDUE_ITEMS.map((item, i) => (
                <div key={i} style={{ padding: "14px 22px", borderBottom: i < OVERDUE_ITEMS.length - 1 ? `1px solid ${T.borderLight}` : "none", display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <span style={{ fontFamily: T.fontSerif, fontWeight: 700, fontSize: 13, color: T.navy }}>{item.gene}</span>
                      <span style={{ fontSize: 11, color: T.text3 }}>{item.id}</span>
                    </div>
                    <div style={{ fontFamily: T.fontMono, fontSize: 11.5, color: T.text2 }}>{item.hgvs}</div>
                    <div style={{ fontSize: 11, color: T.text3, marginTop: 4 }}>Assigned to: {item.assignedTo}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 18, fontWeight: 700, color: T.red, fontFamily: T.fontSerif }}>{item.daysOverdue}</div>
                    <div style={{ fontSize: 10.5, color: T.text3 }}>days overdue</div>
                    <span style={{ fontSize: 10, background: T.redLight, color: T.red, padding: "2px 6px", borderRadius: 4, fontWeight: 600, marginTop: 4, display: "inline-block" }}>{item.classification}</span>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ padding: "12px 22px", borderTop: `1px solid ${T.borderLight}`, textAlign: "center" }}>
              <button style={{ fontSize: 12.5, color: T.primary, background: "none", border: "none", cursor: "pointer", fontWeight: 500 }}>
                Assign to reviewer →
              </button>
            </div>
          </div>

          {/* Reviewer Activity */}
          <div style={{ background: T.white, border: `1px solid ${T.borderLight}`, borderRadius: T.radiusLg, overflow: "hidden", boxShadow: "0 1px 4px rgba(13,31,76,0.05)" }}>
            <div style={{ padding: "16px 22px", borderBottom: `1px solid ${T.borderLight}` }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: T.navyDeep, fontFamily: T.fontSerif }}>Reviewer Activity</div>
            </div>
            <div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 60px 70px 70px 80px", padding: "8px 22px", fontSize: 10.5, fontWeight: 600, color: T.text3, textTransform: "uppercase", letterSpacing: 0.5, background: T.surface, borderBottom: `1px solid ${T.borderLight}` }}>
                <span>Reviewer</span><span style={{ textAlign: "center" }}>Done</span><span style={{ textAlign: "center" }}>Pending</span><span style={{ textAlign: "center" }}>Avg Days</span><span>Last Active</span>
              </div>
              {REVIEWER_ACTIVITY.map((r, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 60px 70px 70px 80px", padding: "12px 22px", alignItems: "center", borderBottom: `1px solid ${T.borderLight}`, transition: "background 0.15s" }}
                  onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = T.navyLight}
                  onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 30, height: 30, borderRadius: "50%", background: `linear-gradient(135deg, ${T.primary}, ${T.navy})`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: 10.5, fontWeight: 700, flexShrink: 0 }}>
                      {r.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: T.navyDeep }}>{r.name}</div>
                      <div style={{ fontSize: 10.5, color: T.text3 }}>{r.role}</div>
                    </div>
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 700, color: T.primary, textAlign: "center" }}>{r.reviewed}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: r.pending > 3 ? T.amber : T.text2, textAlign: "center" }}>{r.pending}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: r.avgDays > 3 ? T.amber : T.green, textAlign: "center" }}>{r.avgDays}d</span>
                  <span style={{ fontSize: 11.5, color: T.text3 }}>{r.lastActive}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
