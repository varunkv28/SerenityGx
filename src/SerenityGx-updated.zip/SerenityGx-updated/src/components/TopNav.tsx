import { DesignTokens } from "../constants/designTokens";

const T = DesignTokens;

interface TopNavProps {
  activePage: string;
  onNavigate?: (page: string) => void;
}

const NAV_ITEMS = [
  "Dashboard",
  "Variant Reclassification",
  "Patient Variant Review",
  "Evidence Surveillance",
  "Leadership Dashboard",
  "Reports",
];

export default function TopNav({ activePage, onNavigate }: TopNavProps) {
  return (
    <nav style={{
      background: `linear-gradient(135deg, ${T.navyDeep} 0%, ${T.navy} 60%, #1a3a8a 100%)`,
      padding: "0 28px",
      height: 60,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      position: "sticky",
      top: 0,
      zIndex: 100,
      boxShadow: "0 2px 16px rgba(13,31,76,0.3)"
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
        <div style={{
          width: 32, height: 32,
          background: `linear-gradient(135deg, ${T.primary}, #3ECFBC)`,
          borderRadius: 8,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 800, color: "white", fontSize: 13,
          fontFamily: T.fontSerif,
          boxShadow: "0 2px 8px rgba(44,177,160,0.4)"
        }}>Gx</div>
        <div style={{ fontFamily: T.fontSerif, fontWeight: 800, fontSize: 18, color: "white", letterSpacing: "-0.3px" }}>
          Serenity<span style={{ color: T.primary, fontWeight: 400, fontSize: 15 }}>Gx</span>
        </div>
      </div>

      <div style={{ display: "flex", gap: 2 }}>
        {NAV_ITEMS.map(label => (
          <span
            key={label}
            onClick={() => onNavigate && onNavigate(label)}
            style={{
              padding: "7px 11px",
              color: activePage === label ? "white" : "rgba(255,255,255,0.65)",
              background: activePage === label ? "rgba(44,177,160,0.2)" : "transparent",
              fontSize: 12,
              fontWeight: activePage === label ? 600 : 500,
              borderRadius: T.radiusSm,
              cursor: "pointer",
              transition: "all 0.2s",
              whiteSpace: "nowrap",
              fontFamily: T.font,
              borderBottom: activePage === label ? `2px solid ${T.primary}` : "2px solid transparent",
            }}
          >
            {label}
          </span>
        ))}
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 14, flexShrink: 0 }}>
        <div style={{ position: "relative", cursor: "pointer", padding: 6, borderRadius: 6 }}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.75)" strokeWidth="2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
          <span style={{
            position: "absolute", top: 4, right: 4,
            width: 7, height: 7, background: T.amber,
            borderRadius: "50%", border: `1.5px solid ${T.navyDeep}`
          }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontWeight: 600, fontSize: 12.5, color: "white", fontFamily: T.font }}>Dr. Sarah Chen</div>
            <div style={{ fontSize: 10.5, color: "rgba(255,255,255,0.55)" }}>Laboratory Director</div>
          </div>
          <div style={{
            width: 34, height: 34, borderRadius: "50%",
            background: `linear-gradient(135deg, ${T.primary}, ${T.navy})`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontWeight: 700, color: "white", fontSize: 12,
            fontFamily: T.fontSerif
          }}>SC</div>
        </div>
      </div>
    </nav>
  );
}
