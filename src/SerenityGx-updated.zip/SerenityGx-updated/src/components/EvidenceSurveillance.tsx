import { useState } from "react";
import { DesignTokens } from "../constants/designTokens";
import TopNav from "./TopNav";

const T = DesignTokens;

const EVIDENCE_DATA = [
  {
    id: 1, variant: "MLH1 c.1852_1854del", gene: "MLH1", hgvs: "c.1852_1854del",
    title: "MLH1 splice-site deletion shows complete loss of function in functional assay cohort",
    journal: "Genetics in Medicine", pubDate: "Nov 28, 2025", pmid: "39301847",
    acmg: ["PS3", "PM2", "PP3"], strength: "Strong",
    delta: "Suggests upgrade to Likely Pathogenic",
    deltaType: "upgrade",
    level1: "Paper independently analyzed. Functional data confirms splice disruption with exon skipping in 94% of transcripts. Supports PVS1 functional null evidence.",
    level2: "Cross-paper synthesis: convergent with 2 prior functional studies (2023, 2024). Net reclassification signal: upgrade to Likely Pathogenic.",
    status: "new", cited: 12,
  },
  {
    id: 2, variant: "BRCA2 c.7008-2A>T", gene: "BRCA2", hgvs: "c.7008-2A>T",
    title: "Updated gnomAD v4.0 allele frequencies for BRCA2 splice-site variants in diverse populations",
    journal: "Nature Genetics", pubDate: "Nov 15, 2025", pmid: "39287134",
    acmg: ["PM2", "BA1"], strength: "Supporting",
    delta: "No reclassification signal",
    deltaType: "neutral",
    level1: "Population data extracted. Variant absent in gnomAD v4.0 controls (n=807,162). Supports PM2 criterion.",
    level2: "No conflict with prior evidence. Incremental support for existing LP classification.",
    status: "new", cited: 8,
  },
  {
    id: 3, variant: "TP53 c.817C>T", gene: "TP53", hgvs: "c.817C>T",
    title: "TP53 missense variant p.Arg273Cys: functional transactivation analysis across 18 target promoters",
    journal: "Cancer Research", pubDate: "Oct 20, 2025", pmid: "39183027",
    acmg: ["PS3", "PS1", "PP2"], strength: "Very Strong",
    delta: "Confirms Pathogenic — no reclassification needed",
    deltaType: "neutral",
    level1: "Functional transactivation assay confirms dominant-negative effect. Supports PS3 at very strong level per ACMG PS3/BS3 calibration.",
    level2: "Corroborates existing Pathogenic classification. No change signal.",
    status: "reviewed", cited: 34, reviewer: "Dr. S. Chen", reviewDate: "Nov 5, 2025",
  },
  {
    id: 4, variant: "PALB2 c.2167_2168del", gene: "PALB2", hgvs: "c.2167_2168del",
    title: "PALB2 frameshift variants in hereditary breast cancer: segregation analysis from 6 ENIGMA families",
    journal: "Journal of Medical Genetics", pubDate: "Sep 30, 2025", pmid: "39102854",
    acmg: ["PVS1", "PP1"], strength: "Very Strong",
    delta: "Suggests upgrade from VUS to Likely Pathogenic",
    deltaType: "upgrade",
    level1: "Segregation data from 6 families: LOD score 2.3. PVS1 applicable — frameshift predicts null variant. PP1 at moderate strength.",
    level2: "Combined with prior case-level data (2024): net signal supports Likely Pathogenic. Recommend reviewer action.",
    status: "new", cited: 6,
  },
  {
    id: 5, variant: "ATM c.7271T>G", gene: "ATM", hgvs: "c.7271T>G",
    title: "Conflicting interpretations of ATM missense variants: computational vs. functional evidence analysis",
    journal: "Human Mutation", pubDate: "Sep 12, 2025", pmid: "39088172",
    acmg: ["BP4", "BS3"], strength: "Moderate",
    delta: "Potential downgrade signal — conflicts with prior LP",
    deltaType: "conflict",
    level1: "In silico tools (REVEL, SpliceAI) predict benign effect. Functional assay shows near-normal kinase activity. Supports BS3 moderate.",
    level2: "CONFLICT DETECTED: Prior evidence supports LP (lab reclassification Jan 2026). This paper introduces conflicting benign functional evidence. Requires reviewer adjudication.",
    status: "new", cited: 19,
  },
];

const STATS = [
  { label: "Papers Ingested Today", value: "14", sub: "From PubMed & curated sources", color: T.primary, icon: "📥" },
  { label: "New Evidence Items", value: "4", sub: "Require reviewer attention", color: T.amber, icon: "📄" },
  { label: "Conflicts Detected", value: "1", sub: "Needs reconciliation", color: T.red, icon: "⚡" },
  { label: "Last Surveillance Run", value: "2h ago", sub: "Daily ingestion complete", color: T.navy, icon: "🔄" },
];

function AcmgTag({ code }: { code: string }) {
  const isPath = code.startsWith("P") || code.startsWith("PS") || code.startsWith("PM") || code.startsWith("PP") || code.startsWith("PVS");
  const isBen = code.startsWith("B") || code.startsWith("BS") || code.startsWith("BP") || code.startsWith("BA");
  const bg = isPath ? T.redLight : isBen ? T.greenLight : T.navyLight;
  const color = isPath ? T.red : isBen ? T.green : T.navy;
  return (
    <span style={{ fontFamily: T.fontMono, fontSize: 10.5, fontWeight: 600, padding: "3px 7px", borderRadius: 4, background: bg, color, border: `1px solid ${isPath ? "rgba(197,48,48,0.2)" : isBen ? "rgba(39,103,73,0.2)" : T.border}` }}>
      {code}
    </span>
  );
}

function DeltaBadge({ delta, type }: { delta: string; type: string }) {
  const map: Record<string, { bg: string; color: string; icon: string }> = {
    upgrade: { bg: T.amberLight, color: T.amber, icon: "↑" },
    conflict: { bg: T.redLight, color: T.red, icon: "⚡" },
    neutral: { bg: T.navyLight, color: T.navy, icon: "—" },
  };
  const s = map[type] || map.neutral;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11.5, fontWeight: 600, background: s.bg, color: s.color, padding: "3px 10px", borderRadius: 6 }}>
      {s.icon} {delta}
    </span>
  );
}

export default function EvidenceSurveillance({ onNavigate }: { onNavigate?: (page: string) => void }) {
  const [expandedId, setExpandedId] = useState<number | null>(1);
  const [filterStatus, setFilterStatus] = useState("All");
  const [filterDelta, setFilterDelta] = useState("All");
  const [searchVal, setSearchVal] = useState("");

  const filtered = EVIDENCE_DATA.filter(e => {
    if (filterStatus !== "All" && e.status !== filterStatus.toLowerCase()) return false;
    if (filterDelta === "Upgrades" && e.deltaType !== "upgrade") return false;
    if (filterDelta === "Conflicts" && e.deltaType !== "conflict") return false;
    if (filterDelta === "Neutral" && e.deltaType !== "neutral") return false;
    if (searchVal && !e.gene.toLowerCase().includes(searchVal.toLowerCase()) && !e.title.toLowerCase().includes(searchVal.toLowerCase()) && !e.hgvs.toLowerCase().includes(searchVal.toLowerCase())) return false;
    return true;
  });

  return (
    <div style={{ fontFamily: T.font, background: T.surface, minHeight: "100vh", color: T.text1 }}>
      <TopNav activePage="Evidence Surveillance" onNavigate={onNavigate} />

      <main style={{ maxWidth: 1300, margin: "0 auto", padding: "28px 32px 48px" }}>
        {/* Breadcrumb */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: T.text3, marginBottom: 16 }}>
          <span onClick={() => onNavigate && onNavigate("Dashboard")} style={{ color: T.primary, cursor: "pointer", fontWeight: 500 }}>Dashboard</span>
          <span>›</span><span>Evidence Surveillance</span>
        </div>

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
          <div>
            <div style={{ fontFamily: T.fontSerif, fontSize: 26, fontWeight: 700, color: T.navyDeep, letterSpacing: -0.3 }}>Evidence Surveillance</div>
            <div style={{ color: T.text3, fontSize: 13.5, marginTop: 4 }}>
              Daily ingestion from PubMed, journals & curated sources · AI-driven Level 1 + Level 2 analysis · All conclusions source-linked
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ fontSize: 12, color: T.primary, background: T.primaryLight, padding: "6px 12px", borderRadius: 6, fontWeight: 600 }}>
              🟢 AI Engine Active
            </div>
            <button style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "8px 16px", borderRadius: T.radiusSm, fontSize: 12.5, fontWeight: 500, cursor: "pointer", background: `linear-gradient(135deg, ${T.navy}, ${T.primary})`, color: "white", border: "none", fontFamily: T.font, boxShadow: `0 2px 8px rgba(44,177,160,0.25)` }}>
              ↺ Run Surveillance Now
            </button>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 28 }}>
          {STATS.map((s, i) => (
            <div key={i} style={{ background: T.white, border: `1px solid ${T.borderLight}`, borderRadius: T.radius, padding: "18px 20px", position: "relative", overflow: "hidden", animation: `fadeInUp 0.4s ease ${i * 0.05}s both`, boxShadow: "0 1px 4px rgba(13,31,76,0.05)" }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: s.color }} />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ fontSize: 28, fontWeight: 700, color: T.navyDeep, fontFamily: T.fontSerif, letterSpacing: -0.5 }}>{s.value}</div>
                  <div style={{ fontSize: 11.5, fontWeight: 600, color: T.text3, textTransform: "uppercase", letterSpacing: 0.5, marginTop: 4 }}>{s.label}</div>
                  <div style={{ fontSize: 11, color: T.text3, marginTop: 2 }}>{s.sub}</div>
                </div>
                <span style={{ fontSize: 20, opacity: 0.6 }}>{s.icon}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: "flex", gap: 10, marginBottom: 20, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ position: "relative", flex: "1", minWidth: 240 }}>
            <svg style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)" }} width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={T.text3} strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input
              value={searchVal}
              onChange={e => setSearchVal(e.target.value)}
              placeholder="Search by gene, variant, or title…"
              style={{ width: "100%", padding: "9px 12px 9px 34px", border: `1px solid ${T.border}`, borderRadius: T.radius, fontSize: 13.5, fontFamily: T.font, color: T.text1, outline: "none", background: T.white, boxSizing: "border-box" }}
            />
          </div>
          <span style={{ fontSize: 11.5, fontWeight: 600, color: T.text3, textTransform: "uppercase", letterSpacing: 0.5 }}>Status:</span>
          {["All", "New", "Reviewed"].map(f => (
            <button key={f} onClick={() => setFilterStatus(f)} style={{ fontSize: 12, padding: "6px 14px", borderRadius: 20, border: `1px solid ${filterStatus === f ? T.primary : T.border}`, background: filterStatus === f ? T.primaryMuted : T.white, color: filterStatus === f ? T.primary : T.text2, cursor: "pointer", fontFamily: T.font, fontWeight: 500, transition: "all 0.2s" }}>{f}</button>
          ))}
          <span style={{ fontSize: 11.5, fontWeight: 600, color: T.text3, textTransform: "uppercase", letterSpacing: 0.5, marginLeft: 8 }}>Signal:</span>
          {["All", "Upgrades", "Conflicts", "Neutral"].map(f => (
            <button key={f} onClick={() => setFilterDelta(f)} style={{ fontSize: 12, padding: "6px 14px", borderRadius: 20, border: `1px solid ${filterDelta === f ? T.navy : T.border}`, background: filterDelta === f ? T.navyLight : T.white, color: filterDelta === f ? T.navy : T.text2, cursor: "pointer", fontFamily: T.font, fontWeight: 500, transition: "all 0.2s" }}>{f}</button>
          ))}
          <span style={{ marginLeft: "auto", fontSize: 12, color: T.text3 }}>Showing <strong style={{ color: T.text2 }}>{filtered.length}</strong> papers</span>
        </div>

        {/* AI Disclaimer banner */}
        <div style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "12px 16px", background: T.navyLight, borderRadius: T.radius, marginBottom: 20, border: `1px solid ${T.borderLight}` }}>
          <span style={{ flexShrink: 0, fontSize: 14 }}>🔒</span>
          <div style={{ fontSize: 12.5, color: T.text2, lineHeight: 1.5 }}>
            <strong style={{ color: T.navyDeep }}>AI suggests — you decide.</strong> All evidence summaries are source-linked; no uncited conclusions. Level 1 reasoning analyzes each paper independently; Level 2 synthesizes across papers. Auto-classification is disabled — all decisions require reviewer sign-off.
          </div>
        </div>

        {/* Evidence Cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {filtered.map(paper => {
            const isExpanded = expandedId === paper.id;
            return (
              <div key={paper.id} style={{
                background: T.white,
                borderRadius: T.radiusLg,
                border: `1px solid ${paper.deltaType === "conflict" ? "rgba(197,48,48,0.3)" : paper.status === "new" ? T.primary : T.borderLight}`,
                overflow: "hidden",
                boxShadow: "0 2px 8px rgba(13,31,76,0.04)",
                transition: "box-shadow 0.2s",
                animation: "fadeInUp 0.35s ease both",
              }}>
                {/* Top accent bar */}
                <div style={{ height: 3, background: paper.deltaType === "conflict" ? T.red : paper.status === "new" ? `linear-gradient(90deg, ${T.primary}, ${T.navy})` : T.borderLight }} />

                <div style={{ padding: "18px 24px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16 }}>
                    <div style={{ flex: 1 }}>
                      {/* Meta row */}
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, flexWrap: "wrap" }}>
                        {paper.status === "new" && <span style={{ fontSize: 9.5, fontWeight: 700, color: T.primary, background: T.primaryMuted, padding: "2px 7px", borderRadius: 3, letterSpacing: 0.5, textTransform: "uppercase" }}>New</span>}
                        {paper.deltaType === "conflict" && <span style={{ fontSize: 9.5, fontWeight: 700, color: T.red, background: T.redLight, padding: "2px 7px", borderRadius: 3, letterSpacing: 0.5, textTransform: "uppercase" }}>⚡ Conflict</span>}
                        <span style={{ fontSize: 12, fontWeight: 600, color: T.navy, fontStyle: "italic" }}>{paper.gene}</span>
                        <span style={{ fontFamily: T.fontMono, fontSize: 11.5, color: T.text2 }}>{paper.hgvs}</span>
                        <span style={{ fontSize: 11, color: T.text3 }}>·</span>
                        <span style={{ fontSize: 11.5, color: T.text3 }}>{paper.journal}</span>
                        <span style={{ fontSize: 11, color: T.text3 }}>·</span>
                        <span style={{ fontSize: 11.5, color: T.text3 }}>{paper.pubDate}</span>
                        <a href={`https://pubmed.ncbi.nlm.nih.gov/${paper.pmid}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: T.primary, fontWeight: 500, textDecoration: "none" }}>PMID: {paper.pmid} ↗</a>
                      </div>

                      {/* Title */}
                      <div style={{ fontSize: 14, fontWeight: 600, color: T.navyDeep, marginBottom: 10, lineHeight: 1.4 }}>{paper.title}</div>

                      {/* Tags row */}
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        {paper.acmg.map(c => <AcmgTag key={c} code={c} />)}
                        <span style={{ fontSize: 11.5, color: T.text3 }}>Strength: <strong style={{ color: T.text2 }}>{paper.strength}</strong></span>
                        <span style={{ fontSize: 11, color: T.text3 }}>·</span>
                        <DeltaBadge delta={paper.delta} type={paper.deltaType} />
                      </div>

                      {/* Reviewed by */}
                      {paper.reviewer && (
                        <div style={{ marginTop: 8, fontSize: 11, color: T.text3, display: "flex", alignItems: "center", gap: 4 }}>
                          <span style={{ width: 14, height: 14, borderRadius: "50%", background: T.primaryMuted, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 8, color: T.primary }}>✓</span>
                          Reviewed by <strong style={{ color: T.text2, fontWeight: 600 }}>&nbsp;{paper.reviewer}</strong>&nbsp;·&nbsp;{paper.reviewDate}
                        </div>
                      )}
                    </div>

                    {/* Action buttons */}
                    <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
                      <button
                        onClick={() => setExpandedId(isExpanded ? null : paper.id)}
                        style={{ padding: "7px 14px", background: isExpanded ? T.navyLight : T.primaryMuted, color: isExpanded ? T.navy : T.primary, border: `1px solid ${isExpanded ? T.border : T.primary}`, borderRadius: T.radiusSm, fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", fontFamily: T.font }}
                      >
                        {isExpanded ? "▲ Collapse" : "▼ AI Analysis"}
                      </button>
                      {paper.status === "new" && (
                        <>
                          <button style={{ padding: "7px 14px", background: `linear-gradient(135deg, ${T.primary}, #1E8A7A)`, color: "white", border: "none", borderRadius: T.radiusSm, fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: T.font }}>
                            ✓ Agree
                          </button>
                          <button style={{ padding: "7px 14px", background: T.white, color: T.text2, border: `1px solid ${T.border}`, borderRadius: T.radiusSm, fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: T.font }}>
                            ✕ Suppress
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Expanded AI Analysis */}
                  {isExpanded && (
                    <div style={{ marginTop: 16, animation: "fadeInUp 0.25s ease" }}>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                        <div style={{ background: T.surface, border: `1px solid ${T.borderLight}`, borderRadius: T.radius, padding: "14px 16px" }}>
                          <div style={{ fontSize: 10.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: T.primary, marginBottom: 8 }}>
                            Level 1 — Individual Paper Reasoning
                          </div>
                          <p style={{ fontSize: 13, color: T.text2, lineHeight: 1.6 }}>{paper.level1}</p>
                        </div>
                        <div style={{ background: paper.deltaType === "conflict" ? T.redLight : T.primaryLight, border: `1px solid ${paper.deltaType === "conflict" ? "rgba(197,48,48,0.2)" : T.primary}`, borderRadius: T.radius, padding: "14px 16px" }}>
                          <div style={{ fontSize: 10.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, color: paper.deltaType === "conflict" ? T.red : T.primary, marginBottom: 8 }}>
                            Level 2 — Cross-Paper Synthesis
                          </div>
                          <p style={{ fontSize: 13, color: T.text2, lineHeight: 1.6 }}>{paper.level2}</p>
                        </div>
                      </div>
                      <div style={{ marginTop: 10, fontSize: 11, color: T.text3, fontStyle: "italic" }}>
                        AI reasoning derived from {paper.cited} indexed papers for this variant. Source citations available on request. AI output does not constitute a clinical classification.
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div style={{ padding: 48, textAlign: "center", color: T.text3, fontSize: 14, background: T.white, borderRadius: T.radiusLg, border: `1px solid ${T.borderLight}` }}>
              No evidence papers match your current filters.
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
