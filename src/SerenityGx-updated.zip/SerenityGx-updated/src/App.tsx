import { useState } from 'react'
import SerenityDashboard from './components/Dashboard'
import VariantReclassification from './components/VariantReclassification'
import PatientVariantReview from './components/PatientVariantReview'
import EvidenceSurveillance from './components/EvidenceSurveillance'
import LeadershipDashboard from './components/LeadershipDashboard'
import Reports from './components/Reports'

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard')

  const handleNavigate = (page: string) => {
    const map: Record<string, string> = {
      'Dashboard': 'dashboard',
      'Variant Reclassification': 'variant-reclassification',
      'Patient Variant Review': 'patient-review',
      'Evidence Surveillance': 'evidence-surveillance',
      'Leadership Dashboard': 'leadership-dashboard',
      'Reports': 'reports',
    }
    setCurrentPage(map[page] ?? 'dashboard')
  }

  return (
    <>
      {currentPage === 'dashboard' && <SerenityDashboard onNavigate={handleNavigate} />}
      {currentPage === 'variant-reclassification' && <VariantReclassification onNavigate={handleNavigate} />}
      {currentPage === 'patient-review' && <PatientVariantReview onNavigate={handleNavigate} />}
      {currentPage === 'evidence-surveillance' && <EvidenceSurveillance onNavigate={handleNavigate} />}
      {currentPage === 'leadership-dashboard' && <LeadershipDashboard onNavigate={handleNavigate} />}
      {currentPage === 'reports' && <Reports onNavigate={handleNavigate} />}
    </>
  )
}

export default App
