export const DesignTokens = {
  // === PRIMARY BRAND (SerenityGx Branding Strategy) ===
  primary: "#2CB1A0",          // Teal/Aqua — precision, life sciences
  primaryLight: "#E6F9F7",
  primaryMuted: "rgba(44,177,160,0.12)",

  // === NAVY / DEEP BLUE ===
  navy: "#1F3C88",             // Deep Blue — trust, credibility, medical confidence
  navyDeep: "#0D1F4C",
  navyLight: "rgba(31,60,136,0.06)",
  navyMid: "#2B52B6",

  // === STATUS COLORS ===
  amber: "#D4920A",
  amberLight: "rgba(212,146,10,0.10)",
  amberMuted: "rgba(212,146,10,0.06)",
  red: "#C53030",
  redLight: "rgba(197,48,48,0.08)",
  green: "#276749",
  greenLight: "rgba(39,103,73,0.08)",

  // === SURFACES ===
  surface: "#F2F5FC",          // Soft blue-tinted background
  white: "#FFFFFF",
  border: "#D4E3F7",
  borderLight: "#EAF1FF",

  // === TEXT ===
  text1: "#0D1F4C",
  text2: "#4A5568",
  text3: "#718096",

  // === SHAPE ===
  radius: 10,
  radiusSm: 6,
  radiusLg: 14,

  // === TYPOGRAPHY (Branding strategy: Avenir/Lato/Montserrat) ===
  font: "'Lato', sans-serif",
  fontSerif: "'Montserrat', sans-serif",   // Montserrat for display/headings
  fontMono: "'JetBrains Mono', monospace",
};
